(function() {
  const form = document.getElementById('productoForm');
  const tabla = document.getElementById('tablaProductos');
  const tbody = document.getElementById('tbodyProductos');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!form.checkValidity()) {
      e.stopPropagation();
      form.classList.add('was-validated');
      return;
    }
    
    agregarProducto();
    form.reset();
    form.classList.remove('was-validated');
  });

  function agregarProducto() {
    const nombre = document.getElementById('nombreProducto').value.trim();
    const categoria = document.getElementById('categoria').value;
    const precio = parseFloat(document.getElementById('precio').value);
    const descuento = document.getElementById('descuento').value + '%';
    const genero = document.querySelector('input[name="genero"]:checked')?.value || '';
    const nuevo = document.getElementById('nuevo').checked ? 'Sí' : 'No';
    const fecha = document.getElementById('fecha').value;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${nombre}</td>
      <td>${categoria}</td>
      <td>${precio.toFixed(2)}</td>
      <td>${descuento}</td>
      <td>${genero}</td>
      <td>${nuevo}</td>
      <td>${fecha}</td>
      <td>
        <button class="btn btn-primary btn-sm me-1 editar"><i class="bi bi-pencil-square"></i></button>
        <button class="btn btn-success btn-sm me-1 guardar d-none"><i class="bi bi-save"></i></button>
        <button class="btn btn-danger btn-sm me-1 eliminar"><i class="bi bi-trash"></i></button>
        <button class="btn btn-secondary btn-sm cancelar d-none"><i class="bi bi-x-circle"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
    tabla.style.display = '';

    agregarEventosBotones(tr);
  }

  function agregarEventosBotones(fila) {
    const btnEditar = fila.querySelector('.editar');
    const btnGuardar = fila.querySelector('.guardar');
    const btnEliminar = fila.querySelector('.eliminar');
    const btnCancelar = fila.querySelector('.cancelar');

    btnEditar.addEventListener('click', () => editarFila(fila));
    btnGuardar.addEventListener('click', () => guardarFila(fila));
    btnEliminar.addEventListener('click', () => eliminarFila(fila));
    btnCancelar.addEventListener('click', () => cancelarEdicion(fila));
  }

  function editarFila(fila) {
    fila.querySelectorAll('td').forEach((td, index) => {
      if (index < 7) {
        const valor = td.innerText.replace('%', '');
        td.innerHTML = `<input class="form-control" value="${valor.trim()}">`;
      }
    });
    fila.querySelector('.editar').classList.add('d-none');
    fila.querySelector('.guardar').classList.remove('d-none');
    fila.querySelector('.cancelar').classList.remove('d-none');
  }

  function guardarFila(fila) {
    fila.querySelectorAll('td').forEach((td, index) => {
      if (index < 7) {
        let input = td.querySelector('input');
        if (input) {
          let value = input.value;
          if (index === 3) value += '%';
          td.innerText = value;
        }
      }
    });

    fila.querySelector('.editar').classList.remove('d-none');
    fila.querySelector('.guardar').classList.add('d-none');
    fila.querySelector('.cancelar').classList.add('d-none');

    Swal.fire('Guardado', 'Datos actualizados correctamente', 'success');
  }

  function eliminarFila(fila) {
    fila.remove();
    if (tbody.children.length === 0) {
      tabla.style.display = 'none';
    }
  }

  function cancelarEdicion(fila) {
    const inputs = fila.querySelectorAll('input');
    inputs.forEach((input, index) => {
      const original = input.defaultValue;
      if (index === 3) {
        input.parentElement.innerText = original + '%';
      } else {
        input.parentElement.innerText = original;
      }
    });

    fila.querySelector('.editar').classList.remove('d-none');
    fila.querySelector('.guardar').classList.add('d-none');
    fila.querySelector('.cancelar').classList.add('d-none');
  }
})();
